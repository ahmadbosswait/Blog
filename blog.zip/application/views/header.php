<?php
global $config;
$blogBaseUrl = $config['base_url'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo $title; ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="<?php echo $keywords; ?>">
    <link href="<?php echo $blogBaseUrl; ?>static/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $blogBaseUrl; ?>static/css/blog.css" rel="stylesheet">
    <link href="<?php echo $blogBaseUrl; ?>static/css/font-awesome.css" rel="stylesheet">
    <script src="<?php echo $blogBaseUrl; ?>static/js/jquery.js"></script>
    <script src="<?php echo $blogBaseUrl; ?>static/js/bootstrap.min.js"></script>
    <script src="<?php echo $blogBaseUrl; ?>static/js/custom.js"></script>

</head>

<body>

<!-- Navigation -->
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo $blogBaseUrl; ?>">Blog</a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li><a href="<?php echo $blogBaseUrl; ?>show/gallery">Gallery</a></li>
                <li><a href="<?php echo $blogBaseUrl; ?>show/contactus">Contact us</a></li>
                <?php if(isset($isLoggedIn) and $isLoggedIn):?>
                <li><a class="cyellow" href="<?php echo $blogBaseUrl; ?>admin">Management</a></li>
                <li><a class="cred" href="<?php echo $blogBaseUrl; ?>auth/logout">Log-out</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

