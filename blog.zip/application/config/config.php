<?php 

$config['base_url'] = 'http://localhost/design-projects/blog/'; // Base URL including trailing slash (e.g. http://localhost/)
$config['base_dir'] = 'C:/xampp/htdocs/design-projects/blog/'; // Base URL including trailing slash (e.g. http://localhost/)


$config['default_controller'] = 'show'; // Default controller to load
$config['error_controller'] = 'error'; // Controller used for errors (e.g. 404, 500 etc)
$config['IMAGE_UPLOAD_PATH']= 'http://localhost/design-projects/blog/static/images/';

$config['adminName'] = 'ahmad';
$config['adminUser'] = 'admin';
$config['adminPass'] = 'admin';

$config['db_host'] = 'localhost'; // Database host (e.g. localhost)
$config['db_name'] = 'blog'; // Database name
$config['db_username'] = 'root'; // Database username
$config['db_password'] = ''; // Database password

?>