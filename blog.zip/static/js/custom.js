$('#mymodal').modal('show');
//modal image gallery
$(document).ready(function(){
    $('#my-gallery img').on('click',function(){
        $('#modal').modal({
            show:true
        })
        var mysrc = this.src;
        $('#modal-img').attr('src', mysrc);
        $('#modal-img').on('click', function(){
            $('#modal').modal('hide')
        })
    });
});